package com.marwan.bimplanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BimplannerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BimplannerApplication.class, args);
	}

}
