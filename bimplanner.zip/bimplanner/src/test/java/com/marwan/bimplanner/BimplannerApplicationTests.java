package com.marwan.bimplanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BimplannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
